# Assignment 12: Seaborn 
### Relational, Distributional, Categorical and Multi-Plots
- Author: Nihit Kumar
- Created: 2026-02-28

[Assignment Source Link](https://docs.google.com/document/d/1s3qALl29_RGUuX2xgrPla2JDDY-sAvsg89esNPBcCWg/edit?tab=t.0)

***

#### Datasets:  
- Student Performance Dataset: `student_data.csv` [Source](https://www.kaggle.com/datasets/devansodariya/student-performance-data)  
- Sales Dataset: `sales_data.csv` [Source](https://www.kaggle.com/datasets/vinothkannaece/sales-dataset)  
- Insurance Dataset: `insurance.csv` [Source](https://www.kaggle.com/datasets/vysakhvms/dataset)  
- Home Price Dataset: `home_data.csv` [Source](https://www.kaggle.com/datasets/prakharrathi25/home-prices-dataset)  
- E-Commerce Dataset: `customer_data.csv` [Source](https://www.kaggle.com/datasets/somesh140/segmentation)  
