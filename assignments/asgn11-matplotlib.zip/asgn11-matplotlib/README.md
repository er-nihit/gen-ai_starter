# Assignment 11: Matplotlib (Core Plot types and visualization)
- Author: Nihit Kumar
- Created: 2026-02-25

[Assignment Source Link](https://docs.google.com/document/d/1J_nAAqkcHRyJ7-6M3h46kls1ZugC0qIAcxc9KF6eAiY/edit?tab=t.0)

***

Dateset Used: `sales_data.csv`  
[Download from Kaggle](https://www.kaggle.com/datasets/vinothkannaece/sales-dataset)
